<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino 1.4.0 (all rights reserved). Visit our store &lt;a href=&quot;https://roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Developer: Leopoldo Armesto Ángel&lt;/p&gt;&lt;p&gt;It uses the following open source projects: &lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1), &lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license), &lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license), &lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/p&gt;&lt;p&gt;Icons made by:&lt;/p&gt;&lt;p&gt;&lt;a href=&quot; http://www.flaticon.com/authors/madebyoliver&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Madebyoliver&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.freepik.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Freepik&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/plainicon&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Plainicon&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/gregor-cresnar&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Gregor Cresnar&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/vectors-market&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Vectors Market&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; http://www.flaticon.com/authors/google&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/dimitry-miroliubov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Dimitry Miroliubov&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; https://www.flaticon.com/authors/eleonor-wang&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Eleonor Wang&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/smashicons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Smashicons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/those-icons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Those Icons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Collaborators: Florentino Fernández Cueto, Lukas Bachschwell&lt;/p&gt;&lt;p&gt;Translations: Tonny Scheuring, Emanuela Del Dottore, Miguel Carlos de Castro Miguel, Zigor Aldazabal, Aske Klok, Joao Moura,Ruslan Bondar, Lukas Bachschwell, Joran Luitan, Maxime Samara&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino 1.4.0 (todos los derechos reservados). Visita nuestra tienda &lt;a href=&quot;https://roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Desarrollador: Leopoldo Armesto Ángel&lt;/p&gt;&lt;p&gt;Esá basado en los siguientes pryectos de código obierto: &lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1), &lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license), &lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license), &lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/p&gt;&lt;p&gt;Icones:&lt;/p&gt;&lt;p&gt;&lt;a href=&quot; http://www.flaticon.com/authors/madebyoliver&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Madebyoliver&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.freepik.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Freepik&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/plainicon&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Plainicon&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/gregor-cresnar&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Gregor Cresnar&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/vectors-market&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Vectors Market&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; http://www.flaticon.com/authors/google&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/dimitry-miroliubov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Dimitry Miroliubov&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; https://www.flaticon.com/authors/eleonor-wang&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Eleonor Wang&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/smashicons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Smashicons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/those-icons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Those Icons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Colaboradores: Florentino Fernández Cueto, Lukas Bachschwell&lt;/p&gt;&lt;p&gt;Traducciones: Tonny Scheuring, Emanuela Del Dottore, Miguel Carlos de Castro Miguel, Zigor Aldazabal, Aske Klok, Joao Moura,Ruslan Bondar, Lukas Bachschwell, Joran Luitan, Maxime Samara&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino (all rights reserved). Visit our store &lt;a href=&quot;tienda.roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;tienda.roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;It uses the following open source projects:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino (todos los derechos reservados). Visita nuestra tienda &lt;a href=&quot;tienda.roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;tienda.roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Utiliza los siguientes programas de código abierto:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (Apache 2.0 license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Visualino is open source software (MIT license). Visit the web site at &lt;a href=&quot;http://www.visualino.net/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;visualino.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;2014-2015 Víctor R. Ruiz &amp;lt;&lt;a href=&quot;mailto:rvr@linotipo.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;rvr@linotipo.es&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;p&gt;It uses the following open source projects:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license).&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;This project is done with the help of &lt;a href=&quot;http://www.facebook.com/groups/arduinograncanaria&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Arduino Gran Canaria&lt;/span&gt;&lt;/a&gt; members.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Visualino es software libre (licencia MIT ). Visite el sitio web en &lt;a href=&quot;http://www.visualino.net/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;visualino.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;2014-2015 Víctor R. Ruiz &amp;lt;&lt;a href=&quot;mailto:rvr@linotipo.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;rvr@linotipo.es&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;p&gt;Este programa usa estos proyectos de software libre:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (licencia LGPL 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (licencia MIT).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (licencia LGPL).&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Este programa está hecho con la ayuda de los miembros de &lt;a href=&quot;http://www.facebook.com/groups/arduinograncanaria&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Arduino Gran Canaria&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Visualino is open source software (MIT license). Visit the web site at &lt;a href=&quot;http://www.visualino.net/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;visualino.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;2014-2015 Víctor R. Ruiz &amp;lt;&lt;a href=&quot;mailto:rvr@linotipo.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;rvr@linotipo.es&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;p&gt;It uses the following open source projects:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot;text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license).&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Visualino es software libre (licencia MIT). Visite el sitio web en &lt;a href=&quot;http://www.visualino.net/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;visualino.net&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;2014-2015 Víctor R. Ruiz &amp;lt;&lt;a href=&quot;mailto:rvr@linotipo.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;rvr@linotipo.es&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;p&gt;Este programa utiliza los siguientes proyectos de software libre:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (licencia LGPL 2.1).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (licencia MIT).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot;text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (licencia LGPL).&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Visualino</source>
        <translation type="vanished">Facilino</translation>
    </message>
    <message>
        <source>about:blank</source>
        <translation type="vanished">Acerca de</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <location filename="../src/mainwindow.cpp" line="983"/>
        <location filename="../src/mainwindow.cpp" line="989"/>
        <source>Demo version</source>
        <translation>Versión demo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="336"/>
        <source>arduino:avr:uno</source>
        <translation>arduino:avr:uno</translation>
    </message>
    <message>
        <source>arduino:avr:nano</source>
        <translation type="vanished">arduino:avr:nano</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>arduino:avr:nano:cpu=atmega328</source>
        <translation>arduino:avr:nano:cpu=atmega328</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="346"/>
        <source>arduino:avr:nano:cpu=atmega328old</source>
        <translation>arduino:avr:nano:cpu=atmega328old</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="351"/>
        <source>arduino:avr:nano:cpu=atmega168</source>
        <translation>arduino:avr:nano:cpu=atmega168</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="356"/>
        <source>arduino:avr:mega</source>
        <translation>arduino:avr:mega</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>arduino:avr:diecimila</source>
        <translation>arduino:avr:diecimila</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="366"/>
        <source>arduino:avr:bt</source>
        <translation>arduino:avr:bt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="371"/>
        <source>Intel:arc32:arduino_101</source>
        <translation>Intel:arc32:arduino_101</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="376"/>
        <source>esp8266:esp8266:generic:CpuFrequency=80,FlashFreq=40,FlashMode=dio,UploadSpeed=115200,FlashSize=512K64,ResetMethod=ck,Debug=Disabled,DebugLevel=None____</source>
        <translation>esp8266:esp8266:generic:CpuFrequency=80,FlashFreq=40,FlashMode=dio,UploadSpeed=115200,FlashSize=512K64,ResetMethod=ck,Debug=Disabled,DebugLevel=None____</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>esp8266:esp8266:nodemcuv2:CpuFrequency=80,UploadSpeed=115200,FlashSize=4M3M</source>
        <translation>esp8266:esp8266:nodemcuv2:CpuFrequency=80,UploadSpeed=115200,FlashSize=4M3M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Export as...</source>
        <translation>Exportar como...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="467"/>
        <source>&amp;Help</source>
        <translation>Ay&amp;uda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="473"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="477"/>
        <location filename="../src/mainwindow.ui" line="1546"/>
        <source>Show/hide categories</source>
        <translation>Mostrar/ocultar categoría</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="481"/>
        <location filename="../src/mainwindow.cpp" line="1824"/>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="488"/>
        <location filename="../src/mainwindow.cpp" line="1840"/>
        <source>Basic I/O</source>
        <translation>E/S Básica</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/mainwindow.cpp" line="1848"/>
        <source>Screen</source>
        <translation>Pantalla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="505"/>
        <location filename="../src/mainwindow.cpp" line="1858"/>
        <source>Communication</source>
        <translation>Comunicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="513"/>
        <location filename="../src/mainwindow.cpp" line="1866"/>
        <source>Sound</source>
        <translation>Sonido</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="522"/>
        <location filename="../src/mainwindow.cpp" line="1888"/>
        <source>Light</source>
        <translation>Luz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="529"/>
        <location filename="../src/mainwindow.cpp" line="1894"/>
        <source>Movement</source>
        <translation>Movimiento</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="538"/>
        <location filename="../src/mainwindow.cpp" line="1904"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="545"/>
        <location filename="../src/mainwindow.cpp" line="1910"/>
        <source>Environment</source>
        <translation>Ambiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="555"/>
        <location filename="../src/mainwindow.cpp" line="1922"/>
        <source>Web Interface</source>
        <translation>Interfaz web</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="569"/>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="602"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="622"/>
        <source>Library</source>
        <translation>Biblioteca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <location filename="../src/mainwindow.ui" line="681"/>
        <source>toolBar</source>
        <translation>Caja de herramientas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="743"/>
        <source>Show/hide</source>
        <translation>Mostrar/Ocultar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="766"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="778"/>
        <location filename="../src/mainwindow.ui" line="781"/>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Verify</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="793"/>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="861"/>
        <source>Upload</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="805"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="814"/>
        <location filename="../src/mainwindow.cpp" line="224"/>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="823"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1110"/>
        <source>&amp;New</source>
        <translation>&amp;Nuevo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <source>&amp;Open...</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>&amp;Save...</source>
        <translation>&amp;Guardar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="992"/>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="997"/>
        <source>Zoom +</source>
        <translation>Ampliar +</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1000"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Zoom -</source>
        <translation>Disminuir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1013"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1016"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1029"/>
        <source>Show/hide doc</source>
        <translation>Mostrar/ocultar documentación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1041"/>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <location filename="../src/mainwindow.cpp" line="1228"/>
        <location filename="../src/mainwindow.cpp" line="1250"/>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <location filename="../src/mainwindow.cpp" line="1410"/>
        <location filename="../src/mainwindow.cpp" line="1433"/>
        <source>My Blocks</source>
        <translation>Mis Bloques</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1044"/>
        <source>Create your custom blocks</source>
        <translation>Crea tus propios bloques</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1069"/>
        <location filename="../src/mainwindow.ui" line="1072"/>
        <source>Delete</source>
        <translation>Borar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1075"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1084"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.ui" line="1102"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1134"/>
        <source>&amp;Quit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1154"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1157"/>
        <source>Copy to clipboard</source>
        <translation>Copiar al portapapeles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1543"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1569"/>
        <source>Search on the documentation</source>
        <translation>Buscar en la documentación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <location filename="../src/mainwindow.cpp" line="1837"/>
        <source>EEPROM</source>
        <translation>EEPROM</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1171"/>
        <location filename="../src/mainwindow.cpp" line="1825"/>
        <source>Interrupts</source>
        <translation>Interrupciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1182"/>
        <location filename="../src/mainwindow.cpp" line="1827"/>
        <source>State Machine</source>
        <translation>Máquina de estado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1193"/>
        <location filename="../src/mainwindow.cpp" line="1831"/>
        <source>Arrays</source>
        <translation>Vectores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1204"/>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Button</source>
        <translation>Botón</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1215"/>
        <location filename="../src/mainwindow.cpp" line="1843"/>
        <source>Bus</source>
        <translation>Bus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1226"/>
        <location filename="../src/mainwindow.cpp" line="1845"/>
        <source>Other</source>
        <translation>Otros</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <location filename="../src/mainwindow.cpp" line="1849"/>
        <source>LCD</source>
        <translation>LCD</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1248"/>
        <location filename="../src/mainwindow.cpp" line="1851"/>
        <source>LED Matrix</source>
        <translation>Matriz LED</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1259"/>
        <location filename="../src/mainwindow.cpp" line="1853"/>
        <source>RGB LEDs</source>
        <translation>LED RGB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1270"/>
        <location filename="../src/mainwindow.cpp" line="1855"/>
        <source>OLED</source>
        <translation>OLED</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1281"/>
        <location filename="../src/mainwindow.cpp" line="1859"/>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <location filename="../src/mainwindow.cpp" line="1861"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1303"/>
        <location filename="../src/mainwindow.cpp" line="1863"/>
        <source>IoT</source>
        <translation>IoT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1314"/>
        <location filename="../src/mainwindow.cpp" line="1867"/>
        <source>Buzzer</source>
        <translation>Zumbador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1325"/>
        <location filename="../src/mainwindow.cpp" line="1869"/>
        <source>Voice</source>
        <translation>Voz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1336"/>
        <location filename="../src/mainwindow.cpp" line="1871"/>
        <source>Mic</source>
        <translation>Micrófono</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1347"/>
        <location filename="../src/mainwindow.cpp" line="1873"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <location filename="../src/mainwindow.cpp" line="1876"/>
        <source>Distance</source>
        <translation>Distancia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <location filename="../src/mainwindow.cpp" line="1889"/>
        <source>Infrared</source>
        <translation>Infrarrojos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1380"/>
        <location filename="../src/mainwindow.cpp" line="1891"/>
        <source>Colour</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1391"/>
        <location filename="../src/mainwindow.cpp" line="1895"/>
        <source>Motors</source>
        <translation>Motores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="1897"/>
        <source>Robot base</source>
        <translation>Base robot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1413"/>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>Robot accessories</source>
        <translation>Acc. robot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.cpp" line="1901"/>
        <source>Robot walk</source>
        <translation>Robot caminante</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.cpp" line="1905"/>
        <source>Controller</source>
        <translation>Controlador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1446"/>
        <location filename="../src/mainwindow.cpp" line="1907"/>
        <source>Filtering</source>
        <translation>Filtrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="1911"/>
        <source>Temperature</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1468"/>
        <location filename="../src/mainwindow.cpp" line="1913"/>
        <source>Humidity</source>
        <translation>Humedad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1479"/>
        <location filename="../src/mainwindow.cpp" line="1915"/>
        <source>Rain</source>
        <translation>Lluvia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1490"/>
        <location filename="../src/mainwindow.cpp" line="1917"/>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1501"/>
        <location filename="../src/mainwindow.cpp" line="1919"/>
        <source>Miscellaneous</source>
        <translation>Variado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1512"/>
        <location filename="../src/mainwindow.cpp" line="1923"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1523"/>
        <location filename="../src/mainwindow.cpp" line="1925"/>
        <source>User Interface</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1534"/>
        <location filename="../src/mainwindow.cpp" line="1928"/>
        <source>Deprecated</source>
        <translation>Obsoleto</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Preferencias</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="vanished">Abrir...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="848"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <source>Save...</source>
        <translation type="vanished">Guardar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="856"/>
        <location filename="../src/mainwindow.ui" line="1129"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="864"/>
        <location filename="../src/mainwindow.ui" line="1105"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="832"/>
        <location filename="../src/mainwindow.ui" line="869"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="29"/>
        <source>Facilino</source>
        <translation>Facilino</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="872"/>
        <source>Ctrl+,</source>
        <translation>Ctrl+,</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="877"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="880"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="893"/>
        <source>Show/hide messages</source>
        <translation>Mostrar/ocultar mensajes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="911"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <source>Monitor</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Show/hide monitor</source>
        <translation>Mostrar/ocultar monitor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <source>Ctrl+Shift+M</source>
        <translation>Ctrl+Mayus+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="930"/>
        <source>Sketch (.ino)</source>
        <translation>Sketch (.ino)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.ui" line="1145"/>
        <source>Save as...</source>
        <translation>Guardar como...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Include...</source>
        <translation>Incluir...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Include</source>
        <translation>Incluir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="956"/>
        <source>Show/hide code</source>
        <translation>Mostrar/ocultar código</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="967"/>
        <source>Show/hide icon labels</source>
        <translation>Mostar/ocultar texto de iconos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="972"/>
        <source>List of examples</source>
        <translation>Lista de ejemplos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="977"/>
        <source>Examples...</source>
        <translation>Ejemplos...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="240"/>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <source>Couldn&apos;t open file to save content: %1.</source>
        <translation>No se pudo abrir el fichero para guardar el contenido:%1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="246"/>
        <source>Done exporting: %1.</source>
        <translation>Exportación realizada: %1.</translation>
    </message>
    <message>
        <source>Import file</source>
        <translation type="vanished">Importar fichero</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="562"/>
        <location filename="../src/mainwindow.cpp" line="1830"/>
        <source>Math</source>
        <translation>Matemáticas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1557"/>
        <location filename="../src/mainwindow.cpp" line="1833"/>
        <source>Curve</source>
        <translation>Curva</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <location filename="../src/mainwindow.cpp" line="1962"/>
        <source>Examples</source>
        <translation>Ejemplos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Include file</source>
        <translation>Incluir fichero</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="438"/>
        <source>Open file</source>
        <translation>Abrir fichero</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="456"/>
        <source>Blockly Files %1</source>
        <translation>Ficheros Blockly %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="476"/>
        <source>Couldn&apos;t open file to read content: %1.</source>
        <translation>No se pudo abrir el fichero para leer el contenido: %1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <source>Done saving.</source>
        <translation>Guardado finalizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <source>Checking license...</source>
        <translation>Comprobando licencia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <source>Changes successfully applied!</source>
        <translation>Cambios aplicados correctamente!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>License Active</source>
        <translation>Licencia activa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>There could be unsaved changes that could be lost. Do you want to save them before continuing?</source>
        <translation>Podría haber cambios no guardados que podrían perderse. ¿Quieres guardarlos antes de continuar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <source>Are you sure you want to change to My Blocks? All changes will be lost!</source>
        <translation>¿Seguro que quieres cambiar a Mis Bloques? ¡Todos los cambios se perderán!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <source>Are you sure you want to exit from My Blocks? All changes will be lost!</source>
        <translation>¿Seguro que quieres salir de Mis Bloques? ¡Todos los cambios se perderán!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1228"/>
        <source>Are you sure you want to add this block to the library?</source>
        <translation>¿Estás seguro de que quieres agregar este bloque a la biblioteca?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1250"/>
        <source>This block already exists in the library. Do you want to update it?</source>
        <translation>Este bloque ya existe en la biblioteca. ¿Quieres actualizarlo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <source>Are you sure you want to update this block from the library?</source>
        <translation>¿Estás seguro de que deseas actualizar este bloque de la biblioteca?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1433"/>
        <source>Are you sure you want to delete this block from the library?</source>
        <translation>¿Estás seguro de que quieres eliminar este bloque de la biblioteca?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1455"/>
        <source>This block does not exist in the library and can&apos;t be deleted.</source>
        <translation>Este bloque no existe en la biblioteca y no puede ser borrado.</translation>
    </message>
    <message>
        <source>This block does not exist in the library and can&apos;t be delete it.</source>
        <translation type="vanished">Este bloque no existe en la biblioteca y no se puede eliminar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1944"/>
        <source>Search on documentation and examples</source>
        <translation>Búscaf en documentación y ejemplos.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1960"/>
        <source>Documentation</source>
        <translation>Documentación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1566"/>
        <location filename="../src/mainwindow.cpp" line="1950"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1410"/>
        <source>This block does not exist in the library. Do you want to add it?</source>
        <translation>Este bloque no existe en la biblioteca. ¿Quieres añadirlo?</translation>
    </message>
    <message>
        <source>Please, restart the application to display the selected language.</source>
        <translation type="vanished">Reinicie la aplicación para mostrar el idioma seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>Finished.</source>
        <translation>Finalizó.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Building...</source>
        <translation>Compilando...</translation>
    </message>
    <message>
        <source>There are unsaved changes that could be lost. Do you want to save them before continuing?</source>
        <translation type="vanished">Hay cambios sin grabar que podría perder. ¿Desea guardarlos antes de continuar?</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="48"/>
        <source>Arduino IDE Program Path</source>
        <translation>Ejecutable del IDE de Arduino</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="71"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="146"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <source>Roboblocks Path</source>
        <translation type="vanished">Ruta de Roboblocks</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="103"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Roboblocks language</source>
        <translation type="obsolete">Idioma de Roboblocks</translation>
    </message>
    <message>
        <source>en-GB</source>
        <translation type="obsolete">en-GB</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Arduino IDE</source>
        <translation>IDE de Arduino</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="102"/>
        <source>Default settings</source>
        <translation>Configuración predeterminada</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="103"/>
        <source>Are you sure? This will erase your current preferences and replace them with the defaults.</source>
        <translation>¿Está seguro? Esta acción reemplazará sus preferencias actuales por las opciones predeterminadas. </translation>
    </message>
    <message>
        <source>Roboblocks</source>
        <translation type="vanished">Roboblocks</translation>
    </message>
    <message>
        <source>HTML (*.html)</source>
        <translation type="vanished">HTML (*.html)</translation>
    </message>
</context>
</TS>
