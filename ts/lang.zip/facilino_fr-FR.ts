<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogue</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino 1.4.0 (all rights reserved). Visit our store &lt;a href=&quot;https://roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Developer: Leopoldo Armesto Ángel&lt;/p&gt;&lt;p&gt;It uses the following open source projects: &lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1), &lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license), &lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license), &lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/p&gt;&lt;p&gt;Icons made by:&lt;/p&gt;&lt;p&gt;&lt;a href=&quot; http://www.flaticon.com/authors/madebyoliver&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Madebyoliver&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.freepik.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Freepik&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/plainicon&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Plainicon&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/gregor-cresnar&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Gregor Cresnar&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/vectors-market&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Vectors Market&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; http://www.flaticon.com/authors/google&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/dimitry-miroliubov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Dimitry Miroliubov&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; https://www.flaticon.com/authors/eleonor-wang&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Eleonor Wang&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/smashicons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Smashicons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/those-icons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Those Icons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Collaborators: Florentino Fernández Cueto, Lukas Bachschwell&lt;/p&gt;&lt;p&gt;Translations: Tonny Scheuring, Emanuela Del Dottore, Miguel Carlos de Castro Miguel, Zigor Aldazabal, Aske Klok, Joao Moura,Ruslan Bondar, Lukas Bachschwell, Joran Luitan, Maxime Samara&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Facilino 1.4.0 (tous les droits sont réservés). Visitez notre boutique &lt;a href=&quot;https://roboticafacil.es&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;roboticafacil.es&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Développeur: Leopoldo Armesto Ángel&lt;/p&gt;&lt;p&gt;Il utilise les projets open source suivants: &lt;a href=&quot;http://www.qt.io/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Qt 5&lt;/span&gt;&lt;/a&gt;, The Qt Company (LGPL license 2.1), &lt;a href=&quot;https://developers.google.com/blockly/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google Blockly&lt;/span&gt;&lt;/a&gt; (MIT license), &lt;a href=&quot;https://github.com/bq/roboblocks&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Roboblocks&lt;/span&gt;&lt;/a&gt;, bq (LGPL license), &lt;a href=&quot;http://visualino.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Visualino&lt;/span&gt;&lt;/a&gt;, Victor Ruíz (MIT license).&lt;/p&gt;&lt;p&gt;Icons made by:&lt;/p&gt;&lt;p&gt;&lt;a href=&quot; http://www.flaticon.com/authors/madebyoliver&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Madebyoliver&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.freepik.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Freepik&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/plainicon&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Plainicon&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/gregor-cresnar&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Gregor Cresnar&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/vectors-market&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Vectors Market&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; http://www.flaticon.com/authors/google&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Google&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot; http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;http://www.flaticon.com/authors/dimitry-miroliubov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Dimitry Miroliubov&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot; https://www.flaticon.com/authors/eleonor-wang&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Eleonor Wang&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/smashicons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Smashicons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;, &lt;a href=&quot;https://www.flaticon.com/authors/those-icons&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Those Icons&lt;/span&gt;&lt;/a&gt; from &lt;a href=&quot;http://www.flaticon.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.flaticon.com&lt;/span&gt;&lt;/a&gt; is licensed by &lt;a href=&quot;http://creativecommons.org/licenses/by/3.0/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;CC 3.0 BY&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Collaborateurs: Florentino Fernández Cueto, Lukas Bachschwell&lt;/p&gt;&lt;p&gt;Traductions: Tonny Scheuring, Emanuela Del Dottore, Miguel Carlos de Castro Miguel, Zigor Aldazabal, Aske Klok, Joao Moura,Ruslan Bondar, Lukas Bachschwell, Joran Luitan, Maxime Samara&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="29"/>
        <source>Facilino</source>
        <translatorcomment>Facilino
</translatorcomment>
        <translation>Facilino</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>X</source>
        <translatorcomment>X</translatorcomment>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <location filename="../src/mainwindow.cpp" line="983"/>
        <location filename="../src/mainwindow.cpp" line="989"/>
        <source>Demo version</source>
        <translation>Version de démonstration</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="336"/>
        <source>arduino:avr:uno</source>
        <translation>arduino:avr:uno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>arduino:avr:nano:cpu=atmega328</source>
        <translation>arduino:avr:nano:cpu=atmega328</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="346"/>
        <source>arduino:avr:nano:cpu=atmega328old</source>
        <translation>arduino:avr:nano:cpu=atmega328old</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="351"/>
        <source>arduino:avr:nano:cpu=atmega168</source>
        <translation>arduino:avr:nano:cpu=atmega168</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="356"/>
        <source>arduino:avr:mega</source>
        <translation>arduino:avr:mega</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="361"/>
        <source>arduino:avr:diecimila</source>
        <translation>arduino:avr:diecimila</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="366"/>
        <source>arduino:avr:bt</source>
        <translation>arduino:avr:bt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="371"/>
        <source>Intel:arc32:arduino_101</source>
        <translation>Intel:arc32:arduino_101</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="376"/>
        <source>esp8266:esp8266:generic:CpuFrequency=80,FlashFreq=40,FlashMode=dio,UploadSpeed=115200,FlashSize=512K64,ResetMethod=ck,Debug=Disabled,DebugLevel=None____</source>
        <translation>esp8266:esp8266:generic:CpuFrequency=80,FlashFreq=40,FlashMode=dio,UploadSpeed=115200,FlashSize=512K64,ResetMethod=ck,Debug=Disabled,DebugLevel=None____</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>esp8266:esp8266:nodemcuv2:CpuFrequency=80,UploadSpeed=115200,FlashSize=4M3M</source>
        <translation>esp8266:esp8266:nodemcuv2:CpuFrequency=80,UploadSpeed=115200,FlashSize=4M3M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <location filename="../src/mainwindow.ui" line="609"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="444"/>
        <source>Export as...</source>
        <translation>Exporter en tant que ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="467"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="473"/>
        <source>&amp;Tools</source>
        <translation>&amp;Outils</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="477"/>
        <location filename="../src/mainwindow.ui" line="1546"/>
        <source>Show/hide categories</source>
        <translation>Afficher/masquer les catégories</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="481"/>
        <location filename="../src/mainwindow.cpp" line="1824"/>
        <source>Control</source>
        <translation>Contrôle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="488"/>
        <location filename="../src/mainwindow.cpp" line="1840"/>
        <source>Basic I/O</source>
        <translation>E / S de base</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="496"/>
        <location filename="../src/mainwindow.cpp" line="1848"/>
        <source>Screen</source>
        <translation>Écran</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="505"/>
        <location filename="../src/mainwindow.cpp" line="1858"/>
        <source>Communication</source>
        <translation>Communication</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="513"/>
        <location filename="../src/mainwindow.cpp" line="1866"/>
        <source>Sound</source>
        <translation>Son</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="522"/>
        <location filename="../src/mainwindow.cpp" line="1888"/>
        <source>Light</source>
        <translation>Lumière</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="529"/>
        <location filename="../src/mainwindow.cpp" line="1894"/>
        <source>Movement</source>
        <translation>Mouvement</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="538"/>
        <location filename="../src/mainwindow.cpp" line="1904"/>
        <source>System</source>
        <translation>Systèm</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="545"/>
        <location filename="../src/mainwindow.cpp" line="1910"/>
        <source>Environment</source>
        <translation>Environment</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="555"/>
        <location filename="../src/mainwindow.cpp" line="1922"/>
        <source>Web Interface</source>
        <translation>Interface Web</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="562"/>
        <location filename="../src/mainwindow.cpp" line="1830"/>
        <source>Math</source>
        <translation>Math</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="569"/>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="602"/>
        <source>&amp;Edit</source>
        <translatorcomment>&amp;Modifier</translatorcomment>
        <translation>&amp;Éditer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="622"/>
        <source>Library</source>
        <translation>Bibliothèque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <location filename="../src/mainwindow.ui" line="681"/>
        <source>toolBar</source>
        <translation>barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <location filename="../src/mainwindow.ui" line="743"/>
        <source>Show/hide</source>
        <translation>Afficher/masquer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="766"/>
        <source>Categories</source>
        <translation>Catégories</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="778"/>
        <location filename="../src/mainwindow.ui" line="781"/>
        <location filename="../src/mainwindow.ui" line="951"/>
        <source>Verify</source>
        <translation>Vérifier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="793"/>
        <location filename="../src/mainwindow.ui" line="796"/>
        <location filename="../src/mainwindow.ui" line="861"/>
        <source>Upload</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="805"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="814"/>
        <location filename="../src/mainwindow.cpp" line="224"/>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="534"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="823"/>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="832"/>
        <location filename="../src/mainwindow.ui" line="869"/>
        <source>Preferences</source>
        <translation>Préférences</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1110"/>
        <source>&amp;New</source>
        <translation>&amp;Nouveau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <location filename="../src/mainwindow.ui" line="1060"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="845"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <source>&amp;Open...</source>
        <translation>&amp;Ouvrir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="848"/>
        <location filename="../src/mainwindow.ui" line="1121"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="853"/>
        <location filename="../src/mainwindow.ui" line="1126"/>
        <source>&amp;Save...</source>
        <translation>&amp;Enregistrer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="856"/>
        <location filename="../src/mainwindow.ui" line="1129"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="864"/>
        <location filename="../src/mainwindow.ui" line="1105"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="872"/>
        <source>Ctrl+,</source>
        <translation>Ctrl+,</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="877"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="880"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="885"/>
        <source>About</source>
        <translation>À propos de</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="893"/>
        <source>Show/hide messages</source>
        <translation>Afficher/masquer les messages</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="911"/>
        <location filename="../src/mainwindow.ui" line="914"/>
        <source>Monitor</source>
        <translation>Moniteur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Show/hide monitor</source>
        <translation>Afficher/masquer le moniteur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="925"/>
        <source>Ctrl+Shift+M</source>
        <translation>Ctrl+Shift+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="930"/>
        <source>Sketch (.ino)</source>
        <translation>Sketch (.ino)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="938"/>
        <location filename="../src/mainwindow.ui" line="1145"/>
        <source>Save as...</source>
        <translation>Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="943"/>
        <source>Include...</source>
        <translation>Inclure...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Include</source>
        <translation>Inclure</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="956"/>
        <source>Show/hide code</source>
        <translation>Afficher/masquer le code</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="967"/>
        <source>Show/hide icon labels</source>
        <translation>Afficher/masquer les étiquettes d&apos;icônes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="972"/>
        <source>List of examples</source>
        <translation>Liste d&apos;exemples</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="977"/>
        <source>Examples...</source>
        <translation>Examples...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="992"/>
        <source>Graph</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="997"/>
        <source>Zoom +</source>
        <translation>Zoom +</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1000"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Zoom -</source>
        <translation>Zoom -</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1013"/>
        <source>Undo</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1016"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Redo</source>
        <translation>Refaire</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1024"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1029"/>
        <source>Show/hide doc</source>
        <translation>Afficher/masquer le document</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1041"/>
        <location filename="../src/mainwindow.ui" line="1052"/>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <location filename="../src/mainwindow.cpp" line="1228"/>
        <location filename="../src/mainwindow.cpp" line="1250"/>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <location filename="../src/mainwindow.cpp" line="1410"/>
        <location filename="../src/mainwindow.cpp" line="1433"/>
        <source>My Blocks</source>
        <translation>Mes blocs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1044"/>
        <source>Create your custom blocks</source>
        <translation>Créez vos blocs personnalisés</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1069"/>
        <location filename="../src/mainwindow.ui" line="1072"/>
        <source>Delete</source>
        <translation>Effacer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1075"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1084"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.ui" line="1102"/>
        <source>Update</source>
        <translation>Mettre à jour</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1134"/>
        <source>&amp;Quit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1154"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1157"/>
        <source>Copy to clipboard</source>
        <translation>Copier dans le presse-papier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1171"/>
        <location filename="../src/mainwindow.cpp" line="1825"/>
        <source>Interrupts</source>
        <translation>Interruptions</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1182"/>
        <location filename="../src/mainwindow.cpp" line="1827"/>
        <source>State Machine</source>
        <translation>Machine à état </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1193"/>
        <location filename="../src/mainwindow.cpp" line="1831"/>
        <source>Arrays</source>
        <translatorcomment>Les matrices</translatorcomment>
        <translation>Les tableaux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1204"/>
        <location filename="../src/mainwindow.cpp" line="1841"/>
        <source>Button</source>
        <translation>Bouton</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1215"/>
        <location filename="../src/mainwindow.cpp" line="1843"/>
        <source>Bus</source>
        <translation>Bus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1226"/>
        <location filename="../src/mainwindow.cpp" line="1845"/>
        <source>Other</source>
        <translation>Autre</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <location filename="../src/mainwindow.cpp" line="1849"/>
        <source>LCD</source>
        <translatorcomment>Écran à cristaux liquides</translatorcomment>
        <translation>LCD</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1248"/>
        <location filename="../src/mainwindow.cpp" line="1851"/>
        <source>LED Matrix</source>
        <translatorcomment>
Matrice de LED</translatorcomment>
        <translation>Matrice à LED</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1259"/>
        <location filename="../src/mainwindow.cpp" line="1853"/>
        <source>RGB LEDs</source>
        <translation>LEDs RVB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1270"/>
        <location filename="../src/mainwindow.cpp" line="1855"/>
        <source>OLED</source>
        <translatorcomment>Une diode électroluminescente organique: DELO</translatorcomment>
        <translation>OLED</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1281"/>
        <location filename="../src/mainwindow.cpp" line="1859"/>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1292"/>
        <location filename="../src/mainwindow.cpp" line="1861"/>
        <source>WiFi</source>
        <translation>WiFi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1303"/>
        <location filename="../src/mainwindow.cpp" line="1863"/>
        <source>IoT</source>
        <translatorcomment>Sauter à la recherche
 

Différents aspects de l’Internet des objets.
L&apos;Internet des objets</translatorcomment>
        <translation>Internet des objets</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1314"/>
        <location filename="../src/mainwindow.cpp" line="1867"/>
        <source>Buzzer</source>
        <translation>Bipeur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1325"/>
        <location filename="../src/mainwindow.cpp" line="1869"/>
        <source>Voice</source>
        <translation>Voix</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1336"/>
        <location filename="../src/mainwindow.cpp" line="1871"/>
        <source>Mic</source>
        <translation>Mic</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1347"/>
        <location filename="../src/mainwindow.cpp" line="1873"/>
        <source>Music</source>
        <translation>Musique</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1358"/>
        <location filename="../src/mainwindow.cpp" line="1876"/>
        <source>Distance</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1369"/>
        <location filename="../src/mainwindow.cpp" line="1889"/>
        <source>Infrared</source>
        <translation>Infrarouge</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1380"/>
        <location filename="../src/mainwindow.cpp" line="1891"/>
        <source>Colour</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1391"/>
        <location filename="../src/mainwindow.cpp" line="1895"/>
        <source>Motors</source>
        <translation>Moteurs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1402"/>
        <location filename="../src/mainwindow.cpp" line="1897"/>
        <source>Robot base</source>
        <translation>Base de robot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1413"/>
        <location filename="../src/mainwindow.cpp" line="1899"/>
        <source>Robot accessories</source>
        <translation>Accessoires de robot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.cpp" line="1901"/>
        <source>Robot walk</source>
        <translation>Marche du  robot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.cpp" line="1905"/>
        <source>Controller</source>
        <translation>Contrôleur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1446"/>
        <location filename="../src/mainwindow.cpp" line="1907"/>
        <source>Filtering</source>
        <translation>Filtration</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="1911"/>
        <source>Temperature</source>
        <translation>Température</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1468"/>
        <location filename="../src/mainwindow.cpp" line="1913"/>
        <source>Humidity</source>
        <translation>Humidité</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1479"/>
        <location filename="../src/mainwindow.cpp" line="1915"/>
        <source>Rain</source>
        <translation>Pluie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1490"/>
        <location filename="../src/mainwindow.cpp" line="1917"/>
        <source>Gas</source>
        <translation>Gaz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1501"/>
        <location filename="../src/mainwindow.cpp" line="1919"/>
        <source>Miscellaneous</source>
        <translation>Divers</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1512"/>
        <location filename="../src/mainwindow.cpp" line="1923"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1523"/>
        <location filename="../src/mainwindow.cpp" line="1925"/>
        <source>User Interface</source>
        <translation>Interface utilisateur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1534"/>
        <location filename="../src/mainwindow.cpp" line="1928"/>
        <source>Deprecated</source>
        <translation>Obsolète</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1543"/>
        <source>View</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1557"/>
        <location filename="../src/mainwindow.cpp" line="1833"/>
        <source>Curve</source>
        <translation>Courbe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1566"/>
        <location filename="../src/mainwindow.cpp" line="1950"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1569"/>
        <source>Search on the documentation</source>
        <translation>Rechercher dans la documentation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <location filename="../src/mainwindow.cpp" line="1837"/>
        <source>EEPROM</source>
        <translation>EEPROM</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <location filename="../src/mainwindow.cpp" line="1962"/>
        <source>Examples</source>
        <translation>Exemples</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="228"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="240"/>
        <location filename="../src/mainwindow.cpp" line="549"/>
        <source>Couldn&apos;t open file to save content: %1.</source>
        <translation>Impossible d&apos;ouvrir le fichier pour enregistrer le contenu:%1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="246"/>
        <source>Done exporting: %1.</source>
        <translation>Exportation terminée:%1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Include file</source>
        <translation>Inclure le fichier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="438"/>
        <source>Open file</source>
        <translation>Ouvrir un fichier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="456"/>
        <source>Blockly Files %1</source>
        <translation>Fichiers Blockly%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="476"/>
        <source>Couldn&apos;t open file to read content: %1.</source>
        <translation>Impossible d&apos;ouvrir le fichier pour lire le contenu:%1.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <source>Done saving.</source>
        <translation>Sauvegarde terminée.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="596"/>
        <source>Checking license...</source>
        <translation>Vérification de la licence ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <source>Changes successfully applied!</source>
        <translation>Changements appliqués avec succès!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="715"/>
        <source>Finished.</source>
        <translation>Fini.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="724"/>
        <source>Building...</source>
        <translation>Compilation...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>License Active</source>
        <translation>Licence active</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1040"/>
        <source>There could be unsaved changes that could be lost. Do you want to save them before continuing?</source>
        <translation>Il pourrait y avoir des modifications non sauvegardées qui pourraient être perdues. Voulez-vous les sauvegarder avant de continuer?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1107"/>
        <source>Are you sure you want to change to My Blocks? All changes will be lost!</source>
        <translation>Êtes-vous sûr de vouloir changer pour Mes Blocs? Tous les changements seront perdus!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1120"/>
        <source>Are you sure you want to exit from My Blocks? All changes will be lost!</source>
        <translation>Êtes-vous sûr de vouloir quitter Mes Blocs? Tous les changements seront perdus!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1228"/>
        <source>Are you sure you want to add this block to the library?</source>
        <translation>Êtes-vous sûr de vouloir ajouter ce bloc à la bibliothèque?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1250"/>
        <source>This block already exists in the library. Do you want to update it?</source>
        <translation>Ce bloc existe déjà dans la bibliothèque. Voulez-vous le mettre à jour?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <source>Are you sure you want to update this block from the library?</source>
        <translation>Êtes-vous sûr de vouloir mettre à jour ce bloc à partir de la bibliothèque?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1410"/>
        <source>This block does not exist in the library. Do you want to add it?</source>
        <translation>Ce bloc n&apos;existe pas dans la bibliothèque. Voulez-vous l&apos;ajouter?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1433"/>
        <source>Are you sure you want to delete this block from the library?</source>
        <translation>Êtes-vous sûr de vouloir supprimer ce bloc de la bibliothèque?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1455"/>
        <source>This block does not exist in the library and can&apos;t be deleted.</source>
        <translation>Ce bloc n&apos;existe pas dans la bibliothèque et ne peut pas être supprimé.</translation>
    </message>
    <message>
        <source>This block does not exist in the library and can&apos;t be delete it.</source>
        <translation type="obsolete">Ce bloc n&apos;existe pas dans la bibliothèque et ne peut pas être supprimé.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1944"/>
        <source>Search on documentation and examples</source>
        <translation>Rechercher dans la documentation et des exemples</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1960"/>
        <source>Documentation</source>
        <translation>Documentation</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/settingsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogue</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="48"/>
        <source>Arduino IDE Program Path</source>
        <translation>Chemin du programme EDI Arduino</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="71"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="103"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.ui" line="146"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="91"/>
        <source>Arduino IDE</source>
        <translation>EDI Arduino</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="102"/>
        <source>Default settings</source>
        <translation>Paramètres par défaut</translation>
    </message>
    <message>
        <location filename="../src/settingsdialog.cpp" line="103"/>
        <source>Are you sure? This will erase your current preferences and replace them with the defaults.</source>
        <translation>Êtes-vous sûr? Cela effacera vos préférences actuelles et les remplacera par les valeurs par défaut.</translation>
    </message>
</context>
</TS>
